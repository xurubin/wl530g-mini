#ifndef		_HOST_H_
#define		_HOST_H_

long	hostAddress (char *string);
int	hostString (char *result, int n, long int host);

#endif
