#ifndef		_ERROR_H_
#define		_ERROR_H_

typedef		enum		ErrStatusTag	{

		errOk,
		errBad

		}		ErrStatusType;

#endif		/*	_ERROR_H_	*/
