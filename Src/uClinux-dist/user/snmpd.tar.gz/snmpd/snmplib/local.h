#ifndef		_LOCAL_H_
#define		_LOCAL_H_

#include <string.h>
#include <stdlib.h>

#endif		/*	_LOCAL_H_	*/
