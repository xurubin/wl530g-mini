#ifndef		_RTE_H_
#define		_RTE_H_

/*
 *	$Header: /cvs/sw/new-wave/user/snmpd/snmplib/rte.h,v 1.1 2002/08/26 05:36:11 steveb Exp $
 *	Author: J. Davin
 *	Copyright 1988, 1989, Massachusetts Institute of Technology
 *	See permission and disclaimer notice in file "notice.h"
 */

#include	<notice.h>

CVoidType	rteInit ();

#endif		/*	_RTE_H_	*/
