#ifndef		_VEC_H_
#define		_VEC_H_

#include	"ctypes.h"

CUnsfType		vecParse (CCharPtrType *vec, CUnsfType vlen, CCharPtrType text);

#endif		/*	_VEC_H_		*/
