#ifndef		_AP0_H_
#define		_AP0_H_

CVoidType	ap0Init (void);

#endif		/*	_AP0_H_	*/
