#ifndef		_UDPVARS_H_
#define		_UDPVARS_H_

CVoidType	udpInit (void);

#define UDPINDATAGRAMS	    0
#define UDPNOPORTS	    1
#define UDPINERRORS	    2
#define UDPOUTDATAGRAMS     3


#endif		/*	_UDPVARS_H_	*/
