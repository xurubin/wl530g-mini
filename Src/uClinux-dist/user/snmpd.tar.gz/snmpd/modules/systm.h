#ifndef		_SYSTM_H_
#define		_SYSTM_H_

CVoidType	systmInit (void);

#endif		/*	_SYSTM_H_	*/
